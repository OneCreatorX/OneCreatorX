{
"Updated":"04/07/2023",
  "Generales/Tools":{
     "Creator": "OneCreatorX",
    "Status": "Functional  and in Development",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/OneCreatorX%203.lua",
  "Updated": "04/07/2023"
  },
 "13276475159":{
    "Creator": "OneCreatorX",
    "Status": "Functional and in Development",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/CoffeShop.lua",
  "Updated": "04/07/2023"
  },
 "6305942109":{
    "Creator": "OneCreatorX",
    "Status": "Beta but Working",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/Pasteler%C3%ADa/LaundryExe.lua",
  "Updated": "04/07/2023"
  },
 "10108131074":{
    "Creator": "OneCreatorX",
    "Status": "Functional from 1-8 worlds",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/EjecuteAllCespet.lua",
  "Updated": "04/07/2023"
  },
 "6915291292":{
    "Creator": "OneCreatorX",
    "Status": "Under Maintenance",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/Pasteler%C3%ADa/ExePanaderia.lua",
  "Updated": "04/07/2023"
  },
 "370731277":{
    "Creator": "OneCreatorX",
    "Status": "Functional",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/LoadyCargadorLinks/Meepcity.lua",
  "Updated": "04/07/2023"
  },
 "12398414727":{
    "Creator": "Cat, OneCreatorX",
    "Status": "Functional",
"Url": "https://raw.githubusercontent.com/AnonyProArg/ScriptsRobloz/main/Math%20answer.lua",
  "Updated": "04/07/2023"
  }
}